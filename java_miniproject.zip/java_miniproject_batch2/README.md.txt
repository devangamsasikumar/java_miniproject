1)This is a miniproject on TicTacToe game in java using the concepts of
applets.
2)In this folder you will be provided with JTicTacToe.java file.
3)This file we need to compile by using the command javac JTicTacToe.java
4)For execution we need to execute the command appletviewer JTicTacToe.java
5)After executing you need to select any button in the grid by X and 
the cpu also selects one button by using O.
6)This continues and if adjacent/diagonal are matched tie/won/lose are 
declared.
7)And displays the dialog that you want to play again or not.